package com.uc.gayados.recipe;


import android.support.v4.app.Fragment;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddIngredientFragment extends Fragment {

    EditText txt_ingredient;
    ListView list_ingredient;
    Button btn_ingredient;

    ArrayList<String> ingredientList;

    InputMethodManager inputMethodManager;

    public AddIngredientFragment() {
        // Required empty public constructor
    }




}
