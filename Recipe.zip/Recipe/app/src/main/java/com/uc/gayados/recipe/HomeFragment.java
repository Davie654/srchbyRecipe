package com.uc.gayados.recipe;


import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.uc.gayados.recipe.Helper.DBHelper;
import com.uc.gayados.recipe.Helper.ImageHelper;
import com.uc.gayados.recipe.Model.RecipeItem;

import java.util.ArrayList;
import java.util.Date;


public class HomeFragment extends Fragment {
    ImageHelper imageHelper = new ImageHelper();
    ArrayList<RecipeItem> bestList;
    ArrayList<RecipeItem> newList;

    Date today = new Date();

    public HomeFragment() {
        // Required empty public constructor
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(com.uc.gayados.recipe.R.layout.fragment_home, container, false);


        FloatingActionButton fab = (FloatingActionButton) view.findViewById(com.uc.gayados.recipe.R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //connect to search recipes page
                FragmentManager manager = getActivity().getSupportFragmentManager();
                SearchFragment searchFragment = new SearchFragment();
                manager.beginTransaction().replace(com.uc.gayados.recipe.R.id.root_layout, searchFragment, searchFragment.getTag()).addToBackStack(null).commit();
            }
        });


        //Connect DB
        DBHelper dbHelper = new DBHelper(getContext(), "Recipes.db", null, 1);

//        int userCount = dbHelper.user_Allcount();
//        if (userCount == 0)
//        {
//            dbHelper.user_Insert("shyoo","0000");
//        }

        ArrayList<RecipeItem> defaultDataList = dbHelper.recipes_SelectAll();
        if(defaultDataList == null || defaultDataList.size() == 0)
        {
            //Set Bicol data 1
            Drawable drawable = getResources().getDrawable(com.uc.gayados.recipe.R.drawable.bicol, getActivity().getTheme());
            byte[] bicol = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Crispy Bicol Express", "panlasangpinoy", today.toString(),
                    "1. Pour 8 cups of water in a cooking pot. Let it boil. \n " +
                            "2. Add 3 pounds of pork belly. Continue to cook for 30 minutes. Remove the pork belly. Let it cool down.co \n " +
                            "3. Stir in coconut milk. Then gradually add 1 medium chopped onion and 3 cloves of garlic. Let boil.\n" +
                            "4. Add 3 to 4 pieces long green pepper sliced. Then cook for 3 minutes \n" +
                            "5. Put 3 tablespoons of shrimp paste into the mix then season with black pepper. Continue to cook until water is reduced. Set aside. \n" +
                            "6. Prepare the pork belly by rubbing in salt. Let it sit for about 10 minutes. \n" +
                            "7. Deep fry pork belly for 8 minutes in a pot of 4 cups of cooking oil. Let it rest for 5 minutes then put it back in the pot to deep fry for about 3 to 5 minutes. \n" +
                            "8. Remove from the heat. Slice. And serve.", "Crispy Bicol Express is one of my favorite versions of Bicol Express. This involves making crispy lechon kawali out of pork belly. It is then finished by pouring a rich, creamy, and spicy sauce on top. This dish makes a good appetizer. It can also be eaten as a main dish with warm rice.",
                    bicol, bicol, 0);

            int bicolId = dbHelper.recipes_GetIdByName("Crispy Bicol Express");
            ArrayList<String> bicolIngre = new ArrayList<>();
            bicolIngre.add("pork belly");
            bicolIngre.add("coconut milk");
            bicolIngre.add("green pepper");
            bicolIngre.add("garlic");
            bicolIngre.add("onion");
            bicolIngre.add("black pepper");
            bicolIngre.add("cooking oil");
            bicolIngre.add("water");

            for (int i = 0; i < bicolIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(bicolId,bicolIngre.get(i));
            }

            //Set Puto data 2
            drawable = getResources().getDrawable(R.drawable.puto, getActivity().getTheme());
            byte[] puto = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Puto", "AllRecipes", today.toString(),
                    "1. Grease small cake, puto molds, or ramekins for use in a steamer. Mix the 4 cups flour, 2 cups sugar, and 1 tablespoon baking powder together in a bowl. In a separate, large bowl, scramble the 6 eggs with the 1 can of evaporated milk and 1 ½ cup of water. Fold the dry mixture into the eggs until evenly blended. Fill the prepared molds 2/3 of the way up with the batter and top with shredded cheese.\n" +
                            "2. Fill a wok or a sauce pan that will hold a steamer basket with a few inches of water. Bring the water to a boil over medium-high heat. Place the molds into a steamer basket and place over the boiling water and cover.\n" +
                            "3. Steam until a toothpick inserted in the center of one of the putos comes out clean, about 30 minutes. Cool on a wire rack and serve warm or at room temperature. \n", "Filipino Steamed Dessert",  puto, puto, 4);

            int putoiId = dbHelper.recipes_GetIdByName("Puto");
            ArrayList<String> putoIngre = new ArrayList<>();
            putoIngre.add("all purpose flour");
            putoIngre.add("sugar");
            putoIngre.add("water");
            putoIngre.add("evaporated milk");
            putoIngre.add("baking powder");
            putoIngre.add("cheese");

            for (int i = 0; i < putoIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(putoiId,putoIngre.get(i));
            }

            //Set Adobo data 3
            drawable = getResources().getDrawable(R.drawable.gcadobo, getActivity().getTheme());
            byte[] gcadobo = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Garlic Chicken Adobo", "AllRecipes", today.toString(), //3 4 5
                    "1. Preheat an outdoor grill for high heat, and lightly oil grate.\n" +
                            "2. In a large pot, mix 1 1/2 cup soy sauce, 1 1/2 cup water, 3/4 cup vinegar, 3 tablespoon honey, 1 1/2 minced garlic, 3 bay leaves, and 1/2 teaspoon pepper. Bring the mixture to a boil, and place the 3 pounds chicken thigh into the pot. Reduce heat, cover, and cook 35 to 40 minutes.\n" + //4
                            "3. Remove chicken, drain on paper towels, and set aside. Discard bay leaves. Return the mixture to a boil, and cook until reduced to about 1 1/2 cups. \n" +
                            "4.Place chicken on the prepared grill, about 5 minutes on each side, until browned and crisp. Serve with the remaining soy sauce mixture.", "This is a very tasty and easy-to-make Filipino chicken dish made with soy sauce, garlic, and vinegar. I can just as easily double or triple the chicken in this recipe to serve guests at a party. Serve over rice with just a little of the sauce (not too much).",
                    gcadobo, gcadobo, 4);

            int gcadobooId = dbHelper.recipes_GetIdByName("Garlic Chicken Adobo");
            ArrayList<String> gcadoboIngre = new ArrayList<>();
            gcadoboIngre.add("soy sauce");
            gcadoboIngre.add("water");
            gcadoboIngre.add("chicken");
            gcadoboIngre.add("vinegar");
            gcadoboIngre.add("honey");
            gcadoboIngre.add("garlic");
            gcadoboIngre.add("black pepper");
            gcadoboIngre.add("bay leaf");

            for (int i = 0; i < gcadoboIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(gcadobooId,gcadoboIngre.get(i));
            }

            //Set lumpia data 4
            drawable = getResources().getDrawable(R.drawable.lumpia, getActivity().getTheme());
            byte[] lumpia = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Shanghai Lumpia", "FilipinoRecipeSite", today.toString(), //3 4 5
                    "1. In a bowl combine the following ingredients. 1 pound ground pork, 1 cup chopped shrimps, 1/4 minced onions, 1/2 chopped carrots, 2 whole eggs, 3 tbsp soy sauce, 3 drops sesame oil, salt and pepper to taste. \n" +
                            "2. Wrap into thin rolls in lumpia wrapper. Fry in deep hot oil.\n" + //4
                            "3. Drain on paper towels. Transfer to aserving platter. \n" +
                            "4.Serve with your favorite catsup or make your own Sweet and Sour Sauce recipe.", "Lumpia meat is composed of ground or finely mince of pork, beef or vegetables. Then once the recipe of lumpia shanghai is cooked, its best served with sweet and sour sauce.",
                    lumpia, lumpia, 4);

            int lumpiaId = dbHelper.recipes_GetIdByName("Shanghai Lumpia");
            ArrayList<String> lumpiaIngre = new ArrayList<>();
            lumpiaIngre.add("ground pork");
            lumpiaIngre.add("shrimp");
            lumpiaIngre.add("onion");
            lumpiaIngre.add("carrot");
            lumpiaIngre.add("eggs");
            lumpiaIngre.add("sesame oil");
            lumpiaIngre.add("black pepper");
            lumpiaIngre.add("salt");
            lumpiaIngre.add("lumpia wrapper");
            lumpiaIngre.add("cooking oil");

            for (int i = 0; i < lumpiaIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(lumpiaId,lumpiaIngre.get(i));
            }


            //Set Munggo Guisado Recipe data 5
            drawable = getResources().getDrawable(R.drawable.monggo, getActivity().getTheme());
            byte[] monggo = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Munggo Guisado", "FilipinoRecipeSite", today.toString(), //3 4 5
                    "1. Boil 1 cup mung beans in water until soft and easily mashed. Set aside.\n" +
                            "2. In a pan, heat 1 tbsp vegetable oil. Cook 1/2 pound pork until it turns slightly brown.\n" + //4
                            "3. Add 2 cloves minced garlic, 1 chopped onions and 2 sliced tomatoes. Sauté for a few seconds until tomatoes wilted.\n" +
                            "4.Pour in 3 cups water and add boiled mung beans.\n" +
                            "5. Season with patis and salt to taste. Bring to boil and let it simmer until thick.\n"+
                            "6. Add ampalaya leaves or substitute. Cover and remove from heat. Serve hot.", "Munggo Guisado is one of my favorite filipino food dishes. It has an inexpensive ingredients and lots of nutrients.",
                    monggo, monggo, 4);

            int monggoId = dbHelper.recipes_GetIdByName("Munggo Guisado");
            ArrayList<String> monggoIngre = new ArrayList<>();
            monggoIngre.add("mung beans");
            monggoIngre.add("water");
            monggoIngre.add("vegetable oil");
            monggoIngre.add("pork");
            monggoIngre.add("garlic");
            monggoIngre.add("onion");
            monggoIngre.add("tomato");
            monggoIngre.add("fish sauce");
            monggoIngre.add("ampalaya leaves");

            for (int i = 0; i < monggoIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(monggoId,monggoIngre.get(i));
            }


            //Set Pork Chop suey data 6
            drawable = getResources().getDrawable(R.drawable.pchopsuey, getActivity().getTheme());
            byte[] pchopsuey = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Pork Chop Suey", "FilipinoChow", today.toString(), //3 4 5
                    "1. Cut 1/2 pounds pork into thin strips. Combine 1 tsp soy sauce, 1 tsp oyster sauce, salt and pepper to taste, and 1 tsp cornstarch. Stir to blend and then add the meat. Marinate for 10 to 15 minutes. Set aside.\n" +
                            "2. In a small bowl, whisk together 2 cups chicken broth, 2 tbsp cornstarch, 2 tbsp oyster sauce and 1/2 tsp sugar. Stir to blend and then set aside.\n" + //4
                            "3. Heat ¼ cup oil in a wok (or deep skillet) over medium heat. Fry pork for about 3 to 5 minutes. Add 3 cloves minced garlic and 1 chopped onion until soft and translucent. Stir in 1 ½ cup halved carrots for about a minute. Add the stir in 3 stalks celery cut 1 inch diagonally, ½ cup chopped red bell pepper, 20 pieces snow peas, 1 can sliced mushrooms, and 1 can cob corns, stir-frying for a minute or two after each addition.\n" +
                            "4.Add the cornstarch mixture. Bring to a boil. Lower the heat and continue stirring until well blended and sauce thickens. Correct seasonings.\n" +
                            "5. Immediately remove from heat after heated through. Transfer to a serving platter. Serve hot the chop suey dish.", "Well, this Pork Chopsuey is a Chinese dish that primarily compose of mixed vegetable with meat like fish, chicken, shrimp, beef and pork, plus an added extra flavor to complete the Filipino adapted recipe.",
                    pchopsuey, pchopsuey, 4);

            int pchopsueyId = dbHelper.recipes_GetIdByName("Pork Chop Suey");
            ArrayList<String> pchopsueyIngre = new ArrayList<>();
            pchopsueyIngre.add("pork");
            pchopsueyIngre.add("soy sauce");
            pchopsueyIngre.add("oyster sauce");
            pchopsueyIngre.add("salt");
            pchopsueyIngre.add("corn starch");
            pchopsueyIngre.add("chicken broth");
            pchopsueyIngre.add("black pepper");
            pchopsueyIngre.add("sugar");
            pchopsueyIngre.add("vegetable oil");
            pchopsueyIngre.add("garlic");
            pchopsueyIngre.add("onion");
            pchopsueyIngre.add("carrot");
            pchopsueyIngre.add("celery");
            pchopsueyIngre.add("red bell pepper");
            pchopsueyIngre.add("snow peas");
            pchopsueyIngre.add("mushroom");
            pchopsueyIngre.add("cob corn");

            for (int i = 0; i < pchopsueyIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(pchopsueyId,pchopsueyIngre.get(i));
            }

            //Set menudo data 7
            drawable = getResources().getDrawable(R.drawable.menudo, getActivity().getTheme());
            byte[] menudo = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Menudo", "FilipinoRecipeSite", today.toString(), //3 4 5
                    "1. In a large bowl, combine 2 pounds pork belly cubes with ½ cup soy sauce and ½ lemon juice (or calamansi juice). Marinate for an hour in the refrigerator. Remove pork from marinade, reserving the liquid.\n" +
                            "2. Heat ¼ cup vegetable oil in a large pot (or casserole) over medium heat. Fry 1 cup dicedpotatoes and 1 cup diced carrots until lightly brown. Remove and set aside.\n" + //4
                            "3. In the same pot, stir-fry the marinated pork; cook until lightly brown. Remove and set aside.\n" +
                            "4. Sauté 3 cloves chopped garlic and 1 chopped onions until fragrant and translucent. Add ½ pound chopped pork liver; stir-fry for 5 minutes. Return pork and accumulated juices to pot; stir to combine.\n"+
                            "5. Add 2 cups tomato sauce,  1 cup water, 1 tsp. brown sugar and 1 bay leaf; stir. Bring to boil then allow to simmer for about 20 to 25 minutes or until pork and liver are tender.\n"+
                            "6. Add potatoes and carrots; stir and cook until tender. Season with salt and pepper. Add 1 cup diced red peppers then simmer for another 2 minutes. Transfer to a platter and serve hot.", "Menudo is another type of Filipino recipe that is compose of a stew of pork meat and liver cubes with potatoes, carrots and tomato sauce.",
                    menudo, menudo, 4);

            int menudoId = dbHelper.recipes_GetIdByName("Menudo");
            ArrayList<String> menudoIngre = new ArrayList<>();
            menudoIngre.add("pork belly");
            menudoIngre.add("pork liver");
            menudoIngre.add("soy sauce");
            menudoIngre.add("lemon");
            menudoIngre.add("vegetable oil");
            menudoIngre.add("garlic");
            menudoIngre.add("onion");
            menudoIngre.add("tomato sauce");
            menudoIngre.add("water");
            menudoIngre.add("brown sugar");
            menudoIngre.add("bay leaf");
            menudoIngre.add("potato");
            menudoIngre.add("carrot");
            menudoIngre.add("bell pepper");
            menudoIngre.add("salt");
            menudoIngre.add("black pepper");

            for (int i = 0; i < menudoIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(menudoId,menudoIngre.get(i));
            }

            //Set Sinigang na Sugpo  data 8
            drawable = getResources().getDrawable(R.drawable.ssugpo, getActivity().getTheme());
            byte[] ssugpo = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Sinigang na Sugpo", "PanlasangPinoy", today.toString(), //3 4 5
                    "1. Pour 2 quarts of water into a cooking pot. Let boil.\n" +
                            "2. Add 3 medium wedged onion and tomato. Cook for 3 minutes.\n" + //4
                            "3. Add 1 pack of Sinigang sa Sampaloc Recipe Mix. Stir.\n" +
                            "4. Put the 1 medium sliced Labanos and 3 long green pepper into the pot. Cook for 2 minutes.\n" +
                            "5. Add the 2.2 pounds of Sugpo. Gently stir. Continue to cook for 5 minutes.\n" +
                            "6. Put 6 pieces of Okra and 15 sliced Sitaw string into the pot. Cook for 2½ to 3 minutes.\n" +
                            "7. Season with 3 table spoon fish sauce and ½ tsp ground black pepper. Stir.\n" +
                            "8. Add Kangkong. Cover the pot. Turn the heat off. Let it stay for at least 5 minutes. Transfer to a serving bowl. Serve!\n" +
                            "9. Share and enjoy!", "This recipe is simple. I recommend this for beginners. when it comes to the ingredient, you should also be able to use shrimp if prawn is not available. Spinach can be used as a substitute to kangkong too.",
                    ssugpo, ssugpo, 4);

            int ssugpoId = dbHelper.recipes_GetIdByName("Sinigang na Sugpo");
            ArrayList<String> ssugpoIngre = new ArrayList<>();
            ssugpoIngre.add("sugpo");
            ssugpoIngre.add("sinigang mix");
            ssugpoIngre.add("okra");
            ssugpoIngre.add("sitaw");
            ssugpoIngre.add("labanos");
            ssugpoIngre.add("tomato");
            ssugpoIngre.add("onion");
            ssugpoIngre.add("long green pepper");
            ssugpoIngre.add("fish sauce");
            ssugpoIngre.add("black pepper");
            ssugpoIngre.add("water");



            for (int i = 0; i < ssugpoIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(ssugpoId,ssugpoIngre.get(i));
            }

            //Set lumpia data 9
            drawable = getResources().getDrawable(R.drawable.tbaboy, getActivity().getTheme());
            byte[] tbaboy = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Spicy Tokwat Baboy", "PanlasangPinoy", today.toString(), //3 4 5
                    "1. Pour 12 to 15 cups water in a cooking pot. Let boil. Add 1 ½ pounds of pig ears and continue to boil in medium heat for 15 minutes.\n" +
                            "2. Discard the water and let the pig ears cool down. Scrape thoroughly until all the hair and top skin are removed.\n" + //4
                            "3. Pour the same amount of water on the same cooking pot. (Note: make sure to throw-out the initial water used.). Let boil.\n" +
                            "4. Add ½ oz cinnamon bark, 2 bunches lemongrass, and pig ears. Cover and continue to boil in medium heat for 1 hour or until the ears becomes tender. Note: add more water if needed.\n" +
                            "5. Meanwhile, heat 3 cups cooking oil on a pan. Fry one side of the 3 slices of tofu for 4 minutes. Turn it over and fry the opposite side for 4 to 5 minutes.\n" +
                            "6. Remove from the pan and slice the tofu into cubes. Set aside.\n" +
                            "7. Remove the pig ears from the pot. Let cool. Slice into serving pieces and then combine with the sliced tofu.\n" +
                            "8. Prepare the spicy vinegar mixture by combining 1 tsp salt, 2 tbsp sugar, 1 ½ cup vinegar, and ½ soy sauce. Stir. Microwave for 15 seconds. Continue to stir until well blended. Add 12 pieces chopped chili peppers, 1 medium sliced onion, and ¼ tsp ground black pepper to the spicy vinegar mixture. Toss.\n" +
                            "9. Pour the vinegar mixture all over the tokwat baboy. Toss.\n" +
                            "10. Top with chopped 4 pieces chopped onion leeks. Serve.", "It is easy to make Spicy Tokwat Baboy. All you need to do is boil the pig ears until tender, fry the tofu, and prepare the spicy vinegar mixture. However, I strongly recommend to ensure that the ears are properly cleaned before doing anything else.",
                    tbaboy, tbaboy, 4);

            int tbaboyId = dbHelper.recipes_GetIdByName("Spicy Tokwat Baboy");
            ArrayList<String> tbaboyIngre = new ArrayList<>();
            tbaboyIngre.add("pig ears");
            tbaboyIngre.add("tofu");
            tbaboyIngre.add("onion leeks");
            tbaboyIngre.add("lemon grass");
            tbaboyIngre.add("cinammon bark");
            tbaboyIngre.add("water");
            tbaboyIngre.add("cooking oil");
            tbaboyIngre.add("vinegar");
            tbaboyIngre.add("soy sauce");
            tbaboyIngre.add("white sugar");
            tbaboyIngre.add("salt");
            tbaboyIngre.add("chili pepper");
            tbaboyIngre.add("long green pepper");
            tbaboyIngre.add("onion");
            tbaboyIngre.add("black pepper");


            for (int i = 0; i < tbaboyIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(tbaboyId,tbaboyIngre.get(i));
            }

            //Set leche data 10
            drawable = getResources().getDrawable(R.drawable.leche, getActivity().getTheme());
            byte[] leche = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Philippines", "Leche Flan", "PanlasangPinoy", today.toString(), //3 4 5
                    "1. Using all 10 eggs, separate the yolk from the egg white (only egg yolks will be used).\n" +
                            "2. Place the egg yolks in a big bowl then beat them using a fork or an egg beater.\n" + //4
                            "3. Add 1 small can of condensed milk and mix thoroughly\n" +
                            "4. Pour-in 1 cup of fresh milk and 1  tsp of Vanilla. Mix well\n" +
                            "5. Put the mold (llanera) on top of the stove and heat using low fire.\n" +
                            "6. Put-in 1 cup of sugar on the mold and mix thoroughly until the solid sugar turns into liquid (caramel) having a light brown color. Note: Sometimes it is hard to find a Llanera (Traditional flan mold) depending on your location. I find it more convenient to use individual Round Pans in making leche flan.\n" +
                            "7. Spread the caramel (liquid sugar) evenly on the flat side of the mold\n" +
                            "8. Wait for 5 minutes then pour the egg yolk and milk mixture on the mold\n" +
                            "9. Cover the top of the mold using an Aluminum foil\n"+
                            "10. Steam the mold with egg and milk mixture for 30 to 35 minutes.\n" +
                            "11.  After steaming, let the temperature cool down then refrigerate.\n" +
                            "12. Serve for dessert. Share and Enjoy!", "In the Philippines, Leche Flan is the top dessert of all time. During celebrations such as parties and town fiestas, the dining table won’t be complete without it.",
                    leche, leche, 4);

            int lecheId = dbHelper.recipes_GetIdByName("Leche Flan");
            ArrayList<String> lecheIngre = new ArrayList<>();
            lecheIngre.add("eggs");
            lecheIngre.add("condensed milk");
            lecheIngre.add("fresh milk");
            lecheIngre.add("sugar");
            lecheIngre.add("vanilla extract");


            for (int i = 0; i < lecheIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(lecheId,lecheIngre.get(i));
            }
            //----------------------------------------------------------------------------------------------------------------------------

            //Set bpor data 1
            drawable = getResources().getDrawable(R.drawable.bpor, getActivity().getTheme());
            byte[] bpor = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Banana & cinnamon porridge", "JamieOliver", today.toString(), //3 4 5
                    "1. For the basic porridge, place 160 g of  oats and 600 ml milk or soya milk into a large pan over a medium heat, and add a tiny pinch of sea salt.\n" +
                            "2. Bring to a steady simmer for 5 to 6 minutes, stirring often to give you a smooth, creamy porridge, and loosening with extra milk, if needed.\n" + //4
                            "3. Serve as is, or while it’s blipping away in the pan, follow the next steps to prepare 2 ripe banana and ½ tsp cinnamon topping.\n" +
                            "4. Peel and slice the bananas at an angle.\n" +
                            "5. Toast the 30 g almonds in a dry non-stick frying pan over a medium heat for 3 to 4 minutes, or until lightly golden.\n" +
                            "6. Stir the cinnamon, 2 tbsp poppy seeds and a little maple syrup or honey through the porridge, then divide between bowls.\n" +
                            "7. Scatter the bananas and almonds on top, then drizzle with a little extra maple syrup or honey, if you like." , "Porridge is a good staple breakfast; it’s cheap, it’s filling and it’s nutritious, plus it’s super-simple to customise to keep things interesting. Have fun with your combos!",
                    bpor, bpor, 4);

            int bporId = dbHelper.recipes_GetIdByName("Banana & cinnamon porridge");
            ArrayList<String> bporIngre = new ArrayList<>();
            bporIngre.add("flaked almonds");
            bporIngre.add("rolled oats");
            bporIngre.add("banana");
            bporIngre.add("milk");
            bporIngre.add("ground cinammon");
            bporIngre.add("poppy seeds");
            bporIngre.add("honey");

            for (int i = 0; i < bporIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(bporId,bporIngre.get(i));
            }

            //Set brice data 2
            drawable = getResources().getDrawable(R.drawable.brice, getActivity().getTheme());
            byte[] brice = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Black rice pudding", "JamieOliver", today.toString(), //3 4 5
                    "1. Cook 200g black rice according to the packet instructions, overcooking it slightly so it’s plump and sticky, then drain and cool.\n" +
                            "2. Meanwhile, peel and destone the 1 ripe mango, blitz the flesh in a blender with the 1 lime juice until smooth, and pour into a bowl.\n" + //4
                            "3. Separately, toast 1 tbsp hazelnuts and 1 tbsp coconut in a dry frying pan until lightly golden, then bash up in a pestle and mortar.\n" +
                            "4. Peel 2 ripe bananas and tear into the blender, then blitz with the 200g milk, 1 tbsp vanilla extract and two-thirds of the black rice – depending on the sweetness of your bananas, you could also add a teaspoon of honey.\n" +
                            "5. Once smooth, stir that back through the rest of the rice – this will give you great texture and colour. Divide between four nice jars or bowls.\n" +
                            "6. Spoon over the blitzed mango, squeeze half a passion fruit over each one, then delicately spoon over the 4 tbsp yoghurt and sprinkle with the hazelnuts and coconut.\n" , "This healthy rice pudding recipe is super-tasty for breakfast. Hazelnut milk contains vitamin B12, helping us to think properly and stay alert, while hazelnuts are super-high in vitamin E, protecting our cells against damage. Enjoy!",
                    brice, brice, 4);

            int briceId = dbHelper.recipes_GetIdByName("Black rice pudding");
            ArrayList<String> briceIngre = new ArrayList<>();
            briceIngre.add("black rice");
            briceIngre.add("ripe mango");
            briceIngre.add("lime");
            briceIngre.add("hazelnuts");
            briceIngre.add("coconut flakes");
            briceIngre.add("banana");
            briceIngre.add("milk");
            briceIngre.add("vanilla");
            briceIngre.add("honey");
            briceIngre.add("yoghurt");
            briceIngre.add("passion fruit");

            for (int i = 0; i < briceIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(briceId,briceIngre.get(i));
            }

            //Set wfeta data 3
            drawable = getResources().getDrawable(R.drawable.wfeta, getActivity().getTheme());
            byte[] wfeta = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Watermelon & feta salad", "JamieOliver", today.toString(), //3 4 5
                    "1. Scoop out and chop 700 g of watermelon flesh into chunks, discarding the peel.\n" +
                            "2. Peel and finely slice 1 small red onion, crumble 180 g of feta cheese, then pick 1 bunch mint leaves, tearing any larger ones.\n" + //4
                            "3. Place it all into a bowl and combine. Drizzle over a little oil and season with black pepper.\n", "This refreshing Watermelon Feta Salad with Mint is perfect for summer. Sweet ripe watermelon salad combined with feta cheese and fresh mint is simply dressed with olive oil and lime juice. It’s a sweet-and-salty combination that looks just beautiful on the table for a backyard cookout, a potluck, or even a Sunday brunch!",
                    wfeta, wfeta, 4);

            int wfetaId = dbHelper.recipes_GetIdByName("Watermelon & feta salad");
            ArrayList<String> wfetaIngre = new ArrayList<>();
            wfetaIngre.add("watermelon");
            wfetaIngre.add("red onion");
            wfetaIngre.add("feta cheese");
            wfetaIngre.add("fresh mint");
            wfetaIngre.add("olive oil");

            for (int i = 0; i < wfetaIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(wfetaId,wfetaIngre.get(i));
            }

            //Set palaska data 4
            drawable = getResources().getDrawable(R.drawable.palaska, getActivity().getTheme());
            byte[] palaska = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Peach & almond Alaska", "JamieOliver", today.toString(), //3 4 5
                    "1. Preheat the grill to high. Toast 80g of flaked almonds on a tray as it heats up, keeping a close eye on them and removing as soon as lightly golden. Slice up 480 g of peaches and divide between four ovenproof bowls, along with their juice. Sit a nice 4 round scoop of ice cream on top of each, and place in the freezer.\n" +
                            "2. Separate the 2 large eggs. Put the whites into the bowl of a free-standing mixer (save the yolks for another recipe), add a pinch of sea salt and whisk until the mixture forms stiff peaks (you could use an electric hand whisk). With the mixer still running, gradually add 100 g sugar until combined. Spoon into a piping bag (I like a star-shaped nozzle) or a large sandwich bag that you can snip the corner off\n" + //4
                            "3. Remove the bowls from the freezer and scatter over the toasted almonds. Pipe the meringue over the ice cream as delicately or roughly as you like. Now – I work two at a time to retain maximum control – pop the bowls under the grill for just 2 minutes, or until golden. Remove carefully and serve right away.\n" , "If you feel funny about partially cooked egg whites, buy the 100% egg whites that come in containers at the market.  Most brands are pure egg whites, with no additives, and they are pasteurized for extra safety.",
                    palaska, palaska, 4);

            int palaskaId = dbHelper.recipes_GetIdByName("Peach & almond Alaska");
            ArrayList<String> palaskaIngre = new ArrayList<>();
            palaskaIngre.add("flaked almonds");
            palaskaIngre.add("peach halves");
            palaskaIngre.add("vanilla ice cream");
            palaskaIngre.add("egg");
            palaskaIngre.add("sugar");
            palaskaIngre.add("");
            palaskaIngre.add("");
            palaskaIngre.add("");
            palaskaIngre.add("");
            palaskaIngre.add("");

            for (int i = 0; i < palaskaIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(palaskaId,palaskaIngre.get(i));
            }


            //Set sveg data 5
            drawable = getResources().getDrawable(R.drawable.sveg, getActivity().getTheme());
            byte[] sveg = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Salmon & pesto-dressed veg", "JamieOliver", today.toString(), //3 4 5
                    "1. For the pesto, peel the ½ cloves of garlic and add half to a jug with the 25g of pine nuts. Pick in the 50g of basil leaves and blitz until finely chopped.\n" +
                            "2. Add 2 to 3 tablespoons of olive oil–you need just enough to give it an oozy consistency – then finely grate and stir through the 15g of Parmesan. Give the mixture a final blitz, then halve 2 lemons and add a squeeze of juice to taste, then season with a pinch of black pepper.\n" + //4
                            "3. Scrub the 600g of potatoes, then trim the 200 g beans and 200 g broccoli. Cook the potatoes in a large pan of boiling salted water for 15 minutes, or until tender, adding the beans and the broccoli for the final 5 minutes.\n" +
                            "4. Meanwhile, heat a large non-stick frying pan over a high heat. Rub the salmon fillets all over with olive oil and season with salt and pepper. Place in the hot pan, skin-side down, turn the heat down to medium and cook for 4 minutes, or until the skin is golden and crisp.\n" +
                            "5. Turn the fillets over, then cook for a further 2 to 3 minutes, or until just cooked through. Remove the pan from the heat, rest for 30 seconds, then add a good squeeze of lemon juice and give the pan a shake.\n" +
                            "6. Drain the vegetables well, then tip into a large bowl. Add the pesto, then toss to coat.\n" +
                            "7. Divide the salmon and vegetables between plates, drizzle over the pan juices, then cut the remaining lemon into wedges for squeezing over.\n" , "Salmon is a great source of both omega 3, which helps to keep our hearts healthy, and vitamin D that helps to make our bones and teeth strong. Panfrying salmon is an easy way to get more oily fish in our diets – served with delicious, pesto-dressed potatoes and greens, it’s a great weeknight dinner. ",
                    gcadobo, gcadobo, 4);

            int Id = dbHelper.recipes_GetIdByName("Salmon & pesto-dressed veg");
            ArrayList<String> Ingre = new ArrayList<>();
            gcadoboIngre.add("potato");
            gcadoboIngre.add("green beans");
            gcadoboIngre.add("broccoli");
            gcadoboIngre.add("salmon");
            gcadoboIngre.add("olive oil");
            gcadoboIngre.add("pine nuts");
            gcadoboIngre.add("garlic");
            gcadoboIngre.add("basil");
            gcadoboIngre.add("parmesan");
            gcadoboIngre.add("lemon");

            for (int i = 0; i < gcadoboIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(gcadobooId,gcadoboIngre.get(i));
            }

            //Set vfry data 6
            drawable = getResources().getDrawable(R.drawable.vfry, getActivity().getTheme());
            byte[] vfry = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Veggie noodle stir-fry", "JamieOliver", today.toString(), //3 4 5
                    "1. Cook the 200g noodles according to the packet instructions, then drain and refresh in cold water (this stops them from over-cooking) and place to one side.\n" +
                            "2. On a chopping board, peel and finely slice 1 red onion, then peel and finely chop 2 cloves of garlic.\n" + //4
                            "3. Peel 5cm ginger using a teaspoon, then chop into matchsticks. Pick ½ bunch coriander leaves and finely chop the stalks.\n" +
                            "4. Cut 1 small broccoli florets off the stalk, halve any larger florets, then thinly slice the stalk. Halve 1 red pepper, scoop out the seeds and pith with a teaspoon, then slice into strips.\n" +
                            "5. Cut 350 g of tofu into rough 2cm cubes. Using a speed-peeler, peel the carrot lengthways into long ribbons.\n" +
                            "6. Trim and halve the chilli lengthways (if using), then run a teaspoon down the cut side to scoop out the seeds and white pith. Finely slice at an angle, then wash your hands thoroughly.\n" +
                            "7. Place a wok or large non-stick frying pan on a medium heat, add 100g cashew nuts, and toast until golden, stirring regularly. Tip into a small bowl.\n" +
                            "8. Place the pan back on a high heat and drizzle in 1 tablespoon of vegetable oil. Add the red onion, garlic, ginger and coriander stalks, then fry for 2 minutes, or until lightly golden, stirring regularly.\n" +
                            "9. Throw in the broccoli, pepper, tofu and 100g og mangetouts, and fry for 2 minutes, stirring regularly.\n"+
                            "10. Stir in the 100 g spinach and allow it to wilt, then add the noodles and 1 carrot ribbons. Toss well for a minute to heat through.\n"+
                            "11. Squeeze over the juice from half the lime, add 1 teaspoon of sesame oil and 2 tablespoons of soy sauce, then toss to coat.\n"+
                            "12. Sprinkle over the sliced chilli (if using), toasted nuts and the reserved coriander leaves, then serve with lime wedges for squeezing.", "A great way to make sure you’re getting the vitamins and minerals your body needs is to eat the rainbow. Eating a mixture of different coloured vegetables, like in this stir-fry, will help you do that. This dish will give you two of your 5-a-day. Of course, feel free to use whatever vegetables you have in the fridge – this is a great dish for using up leftovers too! ",
                    vfry, vfry, 4);

            int vfryId = dbHelper.recipes_GetIdByName("Veggie noodle stir-fry");
            ArrayList<String> vfryIngre = new ArrayList<>();
            vfryIngre.add("rice noodle");
            vfryIngre.add("red onion");
            vfryIngre.add("garlic");
            vfryIngre.add("ginger");
            vfryIngre.add("coriander");
            vfryIngre.add("broccoli");
            vfryIngre.add("red pepper");
            vfryIngre.add("tofu");
            vfryIngre.add("carrot");
            vfryIngre.add("red chili");
            vfryIngre.add("cashew nuts");
            vfryIngre.add("vegetable oil");
            vfryIngre.add("magetaut");
            vfryIngre.add("spinach");
            vfryIngre.add("lime");
            vfryIngre.add("soy sauce");


            for (int i = 0; i < vfryIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(vfryId,vfryIngre.get(i));
            }

            //Set rchicken data 7
            drawable = getResources().getDrawable(R.drawable.rchicken, getActivity().getTheme());
            byte[] rchicken = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Roast chicken with potatoes & carrots", "JamieOliver", today.toString(), //3 4 5
                    "1. Preheat the oven to 220°C/425°F/gas 7.\n" +
                            "2. Scrub, trim and halve 500 g of carrots lengthways.\n" + //4
                            "3. Scrub, peel and halve 600 g of potatoes, quartering any larger ones. Add to a large roasting tray.\n" +
                            "4. Break 1 bulb of garlic bulb into cloves, leaving them unpeeled, then lightly crush with the flat side of a knife. Pick the 5 sprigs of rosemary leaves, discarding the stalks. Add the garlic and rosemary leaves to the tray.\n" +
                            "5. Drizzle with oil, season with sea salt and black pepper, then toss well and spread out in an even layer.\n" +
                            "6. Rub 1.6 kg of chicken all over with a pinch of salt and pepper and a drizzle of oil. Stuff the chicken cavity with the whole lemon and the 5 sprigs of thyme sprigs.\n" +
                            "7. Place the chicken in the tray, on top of the vegetables.\n" +
                            "8. Reduce the oven temperature to 200ºC/400ºF/gas 6, then add the chicken and roast for 45 minutes.\n" +
                            "9. Carefully remove the tray from the oven, use tongs to turn the vegetables over, then spoon any juices from the tray over the chicken.\n" +
                            "10. Return the tray to the oven for a further 30 minutes, or until the chicken is cooked through. To check, pierce a chicken thigh with the tip of a sharp knife – if the juices run clear, it’s done. Otherwise return the tray to the oven, cook for a little while longer and repeat the test.\n" +
                            "11. Once cooked, transfer the chicken to a board and return the vegetables to the oven for a final 5 minutes to crisp up, if needed.\n" +
                            "12. Cover the chicken with a layer of tin foil and a tea towel, then leave to rest for 10 to 15 minutes.\n" +
                            "13. Using a sharp carving knife, carve up the chicken, then serve with the roasted veg. Delicious with a green salad on the side.", "This is a classic Sunday dinner that the whole family will love. It’s super simple too. Always try to buy the best quality chicken you can afford – aim for RSPCA-Assured birds as a minimum, then trade up when you can. I’ve seen the way low-standard chickens are kept and I’d never feed them to my kids.",
                    rchicken, rchicken, 4);

            int rchickenId = dbHelper.recipes_GetIdByName("Roast chicken with potatoes & carrots");
            ArrayList<String> rchickenIngre = new ArrayList<>();
            rchickenIngre.add("carrot");
            rchickenIngre.add("potato");
            rchickenIngre.add("garlic");
            rchickenIngre.add("rosemary");
            rchickenIngre.add("olive oil");
            rchickenIngre.add("chichen");
            rchickenIngre.add("lemon");
            rchickenIngre.add("thyme");

            for (int i = 0; i < rchickenIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(rchickenId,rchickenIngre.get(i));
            }

            //Set qcakes data 8
            drawable = getResources().getDrawable(R.drawable.qcakes, getActivity().getTheme());
            byte[] qcakes = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "Quick fish cakes", "JamieOliver", today.toString(), //3 4 5
                    "1. Roughly chop 500g of fish, then peel and grate 1 large potato.\n" +
                            "2. Combine with 4 tbsp of flour in a bowl, then season with sea salt and black pepper.\n" + //4
                            "3. Bring together with your hands and shape into 12 flat patties, then leave to chill in the fridge.\n" +
                            "4. Heat a glug of oil in a heavy-based pan over a medium-high heat. In batches of 4, cook the fish cakes for 2 to 3 minutes on each side, until golden and crisp, then remove to kitchen paper to drain.\n" +
                            "5. Pick, chop and stir the herbs through 200 ml of mayo, then serve with the fish cakes, and some watercress and lemon wedges, if you like.\n" , "The best of British meets Indian spice in this tasty breakfast dish – great at any time of day.",
                    qcakes, qcakes, 4);

            int qcakesId = dbHelper.recipes_GetIdByName("Quick fish cakes");
            ArrayList<String> qcakesIngre = new ArrayList<>();
            qcakesIngre.add("skinless cod");
            qcakesIngre.add("potato");
            qcakesIngre.add("flour");
            qcakesIngre.add("olive oil");
            qcakesIngre.add("parsley");
            qcakesIngre.add("mayonnaise");

            for (int i = 0; i < qcakesIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(qcakesId,qcakesIngre.get(i));
            }

            //Set bbc data 9
            drawable = getResources().getDrawable(R.drawable.bbc, getActivity().getTheme());
            byte[] bbc = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "BBQ BACON CHEDDAR SLIDERS", "PamperedChef", today.toString(), //3 4 5
                    "1. Prepare the grill for direct cooking over medium-high heat (400-450°F/200-230°C).\n" +
                            "2. Spray the Meatball & Slider Grill Basket with nonstick cooking spray.\n" + //4
                            "3. In a large mixing bowl, combine 340 g of ground beef, 75 ml of bacon, 1/3 cup of cheese and 2 Tbsp/30 mL barbecue sauce, and mix gently until thoroughly combined. Divide the meat mixture into 6 portions.\n" +
                            "4. Sprinkle the bottom of the Burger & Slider Press with 1 tbsp (15 mL) of the French fried onions and add one portion of meat. Press and remove the patty, then repeat with the remaining meat mixture. Place the patties into the slider wells of the basket.\n" +
                            "5. Place the basket on the grid of the grill and grill, covered, for 8-10 minutes, turning once, or until the internal temperature reaches 140°F/60°C for medium doneness.\n" +
                            "6. To serve, top the buns with the sliders, barbecue sauce, remaining French fried onions, and pickles.", "Try this recipe instead- you make one large cheeseburger in a baking pan, then cut it into sliders.  And there's no hands-on cooking, either- just a few minutes in the oven for awesome little burgers on yummy toasted slider buns, topped with bacon, fried onions and barbecue sauce!",
                    bbc, bbc, 4);

            int bbcId = dbHelper.recipes_GetIdByName("BBQ BACON CHEDDAR SLIDERS");
            ArrayList<String> bbcIngre = new ArrayList<>();
            bbcIngre.add("ground beef");
            bbcIngre.add("bacon");
            bbcIngre.add("cheddar cheese");
            bbcIngre.add("barbecue sauce");
            bbcIngre.add("onion");
            bbcIngre.add("buns");
            bbcIngre.add("pickle");

            for (int i = 0; i < bbcIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(bbcId,bbcIngre.get(i));
            }

            //Set BUFFALO CHICKEN SLIDERS data 10
            drawable = getResources().getDrawable(R.drawable.bcs, getActivity().getTheme());
            byte[] bcs = imageHelper.getByteArrayFromDrawable(drawable);

            dbHelper.recipes_Insert("Western", "BUFFALO CHICKEN SLIDERS", "PamperedChef", today.toString(), //3 4 5
                    "1. Prepare the grill for direct cooking over medium heat (350-400°F/180-200°C).  \n" +
                            "2. Spray the Meatball & Slider Grill Basket with nonstick cooking spray.\n" + //4
                            "3. Add the 340g of chicken, 1/3 cup of finely chopped celery, ¼ cup of hot sauce, ½ cup of cheese and ½ cup of bread crumbs to a large bowl; mix gently until thoroughly combined. \n" +
                            "4. Divide the meat mixture into 6 portions. Place the slider insert into the base of the Burger & Slider Press. Lightly spray the base and the press with nonstick cooking spray; press into patties.\n" +
                            "5. Add one portion of the chicken mixture. Press and remove the patty, then repeat with the remaining chicken mixture. Place the patties into the slider wells of the basket.\n" +
                            "6. Grill the patties, covered, 4-5 minutes. Turn the basket over, and grill, covered, an additional 4-5 minutes or until the center of the burgers are no longer pink and the internal temperature reaches 165°F (74°C). Remove the basekt from the grill. \n" +
                            "7. To serve, top the buns with the slider, dressing, and red onions. Sprinkle with additional blue cheese, if desired.\n" , "These buffalo chicken sliders are perfect for game day or just for a quick lunch!",
                    bcs, bcs, 4);

            int bcsId = dbHelper.recipes_GetIdByName("BUFFALO CHICKEN SLIDERS");
            ArrayList<String> bcsIngre = new ArrayList<>();
            bcsIngre.add("ground chicken");
            bcsIngre.add("celery");
            bcsIngre.add("hot sauce");
            bcsIngre.add("blue cheese");
            bcsIngre.add("bread crumbs");
            bcsIngre.add("ranch dressing");
            bcsIngre.add("buns");
            bcsIngre.add("onion");

            for (int i = 0; i < bcsIngre.size(); i++)
            {
                dbHelper.ingredients_Insert(bcsId,bcsIngre.get(i));
            }


        }

        TextView resultTextView = (TextView) view.findViewById(com.uc.gayados.recipe.R.id.txt_DBresult);
        //resultTextView.setText(tempcategory);

        newList = dbHelper.recipes_SelectNew();




        //connect GrieView code to UI
        GridView bestGridView = (GridView)view.findViewById(com.uc.gayados.recipe.R.id.GridView_Best);

        bestList = dbHelper.recipes_SelectBest();

        bestGridView.setAdapter(new MainRecipeAdapter(this.getContext(), bestList, com.uc.gayados.recipe.R.layout.fragment_home_recipeitem));

        bestGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                RecipeItem selectRecipe = bestList.get(position);
                Intent intent = new Intent(getActivity(), RecipeActivity.class);
                intent.putExtra("recipe", selectRecipe.get_recipeName());
                startActivity(intent);
                //Toast.makeText(view.getContext(),selectRecipe.get_recipName(),Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }

}
