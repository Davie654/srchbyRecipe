package com.uc.gayados.recipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class TempSearchResultActivity extends AppCompatActivity {

    ArrayList<Integer> sendRecipeList = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.uc.gayados.recipe.R.layout.activity_temp_search_result);

        //test dummy data
        sendRecipeList.add(1);
        sendRecipeList.add(2);
        sendRecipeList.add(3);
        sendRecipeList.add(4);

        Button send= (Button)findViewById(com.uc.gayados.recipe.R.id.btn_sendRecipeList);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RecipeListActivity.class);
                intent.putExtra("title", "Matchgin 3 ingredients");
                intent.putIntegerArrayListExtra("list", sendRecipeList);
                startActivity(intent);
            }
        });
    }
}
